# Resumo

## *Colocar aqui título com máximo de dez palavras* *Opcionalmente, colocar aqui sub-título com máximo de vinte palavras* {#colocar-aqui-título-com-máximo-de-dez-palavras-opcionalmente-colocar-aqui-sub-título-com-máximo-de-vinte-palavras .unnumbered}

*Deve conter entre 100 e 200 palavras.*

\...

\...

**Palavras-chave**: *indique entre 5 e 10 palavras-chave, separadas por
vírgulas, sobre o tema do trabalho*.

# Abstract

## *Colocar aqui título com máximo de dez palavras* *Opcionalmente, colocar aqui sub-título com máximo de vinte palavras* {#colocar-aqui-título-com-máximo-de-dez-palavras-opcionalmente-colocar-aqui-sub-título-com-máximo-de-vinte-palavras-1 .unnumbered}

*Between 100 and 200 words.*

\...

\...

**Keywords**: *Specify between 5 and 10 keywords, separated by commas,
about the theme of the report*.

texto de agradecimento

# Introdução {#intro}

Sugestão de capítulos e/ou secções para relatórios de projetos ou
dissertações de mestrado:

1.  Introdução: tema, objetivo geral, a quem se destina, o que é suposto
    o leitor saber, apresentação da estrutura do documento (quais os
    capítulos que o constituem e uma frase resumo sobre o conteúdo de
    cada um);

2.  Motivação para o tema (pode estar no capítulo de introdução); porque
    é que é importante o tema do trabalho;

3.  Descrição e apresentação clara do problema que se pretende resolver;
    deve ficar claro porque é que é importante/útil resolver esse
    problema;

4.  Estado da arte/trabalho relacionado (o que existe / o que se sabe
    sobre o problema a resolver); é um capítulo teórico que pode
    apresentar o que importa saber sobre o problema;

5.  Descrição dos métodos para resolver o problema; pode incluir uma
    descrição das tecnologias, ferramentas e linguagens utilizadas, se
    foi feito um inquérito, etc.;

6.  Um ou mais capítulos/secções sobre o que foi feito; por exemplo,
    análise, projecto, implementações e teste/validação;

7.  Discussão / Conclusão (podem ser capítulos separados)

Importa ter presente que o principal objetivo do documento é o leitor
perceber o que foi feito e porque é que é importante/útil. Também deve
permitir que o leitor fique a saber onde encontrar mais informação sobre
o tema do trabalho desenvolvido.

Outras indicações sobre LaTeX:

1.  Não se preocupe com as formatações. Utilize as que já estão
    exemplificadas no Capítulo [4](#cap2){reference-type="ref"
    reference="cap2"};

2.  Em especial, não se preocupe com o sítio em que ficam as figuras e
    tabelas; estes são elementos *flutuantes* (*floating*) e são
    arrumados automaticamente pelo LaTeX; ficarão tanto melhor arrumados
    quanto mais texto houver; muitos elementos flutuantes em pouco texto
    não costuma permitir um documento com um *layout* equilibrado;
    quando **concluir** a escrita do texto poderá então fazer pequenos
    ajustes na posição das figuras e tabelas utilizando, por exemplo, os
    seguintes métodos: alterar a dimensão das figuras (devem ficar o
    mais pequenas possível desde que legíveis na dimensão A4); inserir
    quebras de página (`\pagebreak`), alterar o local no texto em que
    surge o comando de inserção de cada figura; utilizar o especificador
    \"H\" (ver
    <https://www.overleaf.com/learn/latex/Positioning_of_Figures>).

3.  Procure evitar o comando `\pagebreak`. Só o deve utilizar no final
    para eventuais ajustes na paginação.

4.  Deve referir cada uma das figuras, listagens e tabelas pelo menos
    uma vez; utilize sempre o comando `\ref{umaLabel}`. Por exemplo:
    \"na Fig.`\ref{fig:exemplofig}`\" ou \"A Listagem
    `\ref{lst:exemplolst01}`\";

5.  Para referir capítulos, secções figuras, listagens e tabelas utilize
    \"Capítulo`\ref{cap:exemplo}`\", \"Secção `\ref{sec:exemplo}`\",
    \"Fig. `\ref{fig:exemplo}`\", \"Listagem `\ref{lst:exemplo}`\" e
    \"Tabela `\ref{tab:exemplo}`\", respectivamente;

6.  Se pretender forçar uma mudança de linha pode utilizar `\\`; se
    quiser que essa linha partida fique justificada, ocupando toda a
    largura da página, pode utilizar o comando `\linebreak`;

7.  Para que o LaTeXrespeite a regra, em português, de hífen na mudança
    de linha, deve utilizar o comando `"-` em lugar de `-`. Por exemplo,
    deve escrever `arco"-íris` em lugar de `arco-íris`. Desta forma,
    quando mudar de linha no hífen, a palavra **arco\"-íris** ficará em
    duas partes: \"arco-\" no fim de uma linha e \"-íris\" no início da
    linha seguinte, tal como sucedeu na linha anterior. Se não conhece
    esta regra, consulte, por exemplo, a seguinte página no
    Ciberdúvidas:
    <https://ciberduvidas.iscte-iul.pt/consultorio/perguntas/a-barra-e-o-hifen-na-translineacao/12731>.

# Título do Capítulo 2 {#cap2}

Este capítulo exemplifica a utilização de referências, figuras, tabelas
e listagens.

## Titulo de uma seção

Deve haver aqui uma frase.

### Título de uma subseção

#### Título de parágrafo de texto normal

Eis duas citações [@book:Brooks1995; @Chen1976]. E mais exemplos de
citações [@AndroidDoc], [@Huetal2000; @book:Brooks1995; @Chen1976] A
Figura [4.1](#fig:exemplofig){reference-type="ref"
reference="fig:exemplofig"} apresenta os vários tipos de diagrama da
Unified Modeling Language (UML).

<figure id="fig:exemplofig" data-latex-placement="!htb">
<span class="image placeholder" data-original-image-src="exemploFig"
data-original-image-title="" width="16cm"></span>
<figcaption>Exemplo de Figura (<em>in</em> <a
href="http://en.wikipedia.org/wiki/Class_diagram"
class="uri">http://en.wikipedia.org/wiki/Class_diagram</a>)</figcaption>
</figure>

## Exemplos de Listagens

A Listagem [\[lst:py\]](#lst:py){reference-type="ref"
reference="lst:py"} apresenta um exemplo de implementação do algoritmo
de ordenação *quicksort* na linguagem de programação Python.

::: tcolorbox
``` python
# in http://www.ics.uci.edu/~eppstein/161/python/quicksort-inplace.py - 2013/04/14
# quick sort, in-place 3-way partition
# David Eppstein, UCI, 17 Jan 2002
def swap(A,i,j):
	temp = A[i]
	A[i] = A[j]
	A[j] = temp
```

[]{#lst:py label="lst:py"}
:::

A Listagem [\[lst:java\]](#lst:java){reference-type="ref"
reference="lst:java"} apresenta um exemplo de implementação do algoritmo
de ordenação *quicksort* na linguagem de programação .

::: tcolorbox
``` java
//  in http://gauss.ececs.uc.edu/Courses/C321/html/quicksort.java.html - 2013/04/14

// QuickSort Solution in Java
// (input must be a list of distinct integers)

import java.io.*;
import java.util.*;

public class QuickSort
{
   public static void swap (int A[], int x, int y)
   {
      int temp = A[x];
      A[x] = A[y];
      A[y] = temp;
   }

   // Reorganizes the given list so all elements less than the first are 
   // before it and all greater elements are after it.                   
   public static int partition(int A[], int f, int l)
   {
      int pivot = A[f];
      while (f < l)
      {
         if (A[f] == pivot || A[l] == pivot) 
         {
            System.out.println("Only distinct integers allowed - C321");
            System.out.println("students should ignore this if statement");
            System.out.exit(0);
         }
         while (A[f] < pivot) f++;
         while (A[l] > pivot) l--;
         swap (A, f, l);
      }
      return f;
   }

   public static void Quicksort(int A[], int f, int l)
   {
      if (f >= l) return;
      int pivot_index = partition(A, f, l);
      Quicksort(A, f, pivot_index);
      Quicksort(A, pivot_index+1, l);
   }

   // Usage: java QuickSort [integer] ...
   // All integers must be distinct
   public static void main(String argv[])
   {
      int A[] = new int[argv.length];
      for (int i=0 ; i < argv.length ; i++)
         A[i] = Integer.parseInt(argv[i]);

      Quicksort(A, 0, argv.length-1);

      for (int i=0 ; i < argv.length ; i++) System.out.print(A[i] + " ");
      System.out.println();
   }
}
```

[]{#lst:java label="lst:java"}
:::

A Listagem [\[lst:javaparcial\]](#lst:javaparcial){reference-type="ref"
reference="lst:javaparcial"} apresenta apenas o método
`void Quicksort(int A[], int f, int l)`{.text}. Para tal são indicadas a
linha inicial e a linha final a importar do ficheiro.

::: tcolorbox
``` {.java firstline="38" lastline="44"}
//  in http://gauss.ececs.uc.edu/Courses/C321/html/quicksort.java.html - 2013/04/14

// QuickSort Solution in Java
// (input must be a list of distinct integers)

import java.io.*;
import java.util.*;

public class QuickSort
{
   public static void swap (int A[], int x, int y)
   {
      int temp = A[x];
      A[x] = A[y];
      A[y] = temp;
   }

   // Reorganizes the given list so all elements less than the first are 
   // before it and all greater elements are after it.                   
   public static int partition(int A[], int f, int l)
   {
      int pivot = A[f];
      while (f < l)
      {
         if (A[f] == pivot || A[l] == pivot) 
         {
            System.out.println("Only distinct integers allowed - C321");
            System.out.println("students should ignore this if statement");
            System.out.exit(0);
         }
         while (A[f] < pivot) f++;
         while (A[l] > pivot) l--;
         swap (A, f, l);
      }
      return f;
   }

   public static void Quicksort(int A[], int f, int l)
   {
      if (f >= l) return;
      int pivot_index = partition(A, f, l);
      Quicksort(A, f, pivot_index);
      Quicksort(A, pivot_index+1, l);
   }

   // Usage: java QuickSort [integer] ...
   // All integers must be distinct
   public static void main(String argv[])
   {
      int A[] = new int[argv.length];
      for (int i=0 ; i < argv.length ; i++)
         A[i] = Integer.parseInt(argv[i]);

      Quicksort(A, 0, argv.length-1);

      for (int i=0 ; i < argv.length ; i++) System.out.print(A[i] + " ");
      System.out.println();
   }
}
```

[]{#lst:javaparcial label="lst:javaparcial"}
:::

## Um exemplo de tabela

A Tabela [4.1](#tab:caso){reference-type="ref" reference="tab:caso"}
apresenta os resultados de aplicação de quatro métodos a um caso. Não é
suportado (ainda) uma distinção entre \"Quadro\" e \"Tabela\" dado que
essa distinção não parece estar formalizada em Portugal (ver, por
exemplo, a resposta no
[ciberdúvidas](https://ciberduvidas.iscte-iul.pt/consultorio/perguntas/tabela-vs-quadro-e-figura-vs-ilustracao/32273)).

::: {#tab:caso}
  Caso   Método 1    Método 2    Método 3
  ------ ---------- ---------- ----------
  1      50            837            970
  2      47            877            230
  3      31             25            415
  4      35            144           2356
  5      45            300            556

  : Uma tabela de exemplo
:::

[]{#tab:caso label="tab:caso"}

# Título do Capítulo 3 {#cap3}

Mais umas citações [@AndroidDoc; @Chen1976]

# Título do Apêndice I {#ap1}

# Título do Anexo I {#an1}

Documento elaborado com base no , disponível em
<https://www.overleaf.com/project/5d936b9ea273390001434a37>, , Autor:
João Paulo Barros, joao.barros@ipbeja.pt
